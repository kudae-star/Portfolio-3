/* Weston Zhanje portfolio interactions — vanilla JavaScript */
"use strict";

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

// Theme switch with persistence.
const savedTheme = localStorage.getItem("wz-theme");
if (savedTheme) document.documentElement.dataset.theme = savedTheme;
$("#themeToggle")?.addEventListener("click", () => {
  const next = document.documentElement.dataset.theme === "light" ? "dark" : "light";
  document.documentElement.dataset.theme = next;
  localStorage.setItem("wz-theme", next);
  $("#themeToggle").innerHTML = next === "light" ? "☾ <span>Theme</span>" : "☼ <span>Theme</span>";
});
if (savedTheme === "light") $("#themeToggle").innerHTML = "☾ <span>Theme</span>";

// Typing animation.
const typedTarget = $("#typedText");
const phrases = ["Frontend Developer", "MSU Student", "UI Explorer", "Creative Problem Solver"];
let phraseIndex = 0, charIndex = 0, deleting = false;
function typeLoop() {
  if (!typedTarget) return;
  const phrase = phrases[phraseIndex];
  typedTarget.textContent = phrase.slice(0, charIndex);
  if (!deleting && charIndex < phrase.length) charIndex++;
  else if (!deleting) { deleting = true; setTimeout(typeLoop, 1200); return; }
  else if (charIndex > 0) charIndex--;
  else { deleting = false; phraseIndex = (phraseIndex + 1) % phrases.length; }
  setTimeout(typeLoop, deleting ? 42 : 85);
}
if (reducedMotion) typedTarget.textContent = phrases[0]; else typeLoop();

// Scroll progress and active navigation.
const progress = $("#topProgress");
window.addEventListener("scroll", () => {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  if (progress) progress.style.width = `${max > 0 ? (window.scrollY / max) * 100 : 0}%`;
}, { passive: true });
const navLinks = $$(".nav-link[href^='#']");
const sectionObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) navLinks.forEach(link => link.classList.toggle("active", link.getAttribute("href") === `#${entry.target.id}`));
  });
}, { rootMargin: "-35% 0px -55% 0px" });
$$("main section[id]").forEach(section => sectionObserver.observe(section));

// Animate skills when visible.
const skillsObserver = new IntersectionObserver(entries => entries.forEach(entry => {
  if (entry.isIntersecting) {
    $$(".progress-bar", entry.target).forEach(bar => bar.style.width = bar.dataset.width);
    skillsObserver.unobserve(entry.target);
  }
}), { threshold: .25 });
const skillsPanel = $(".skills-panel");
if (skillsPanel) skillsObserver.observe(skillsPanel);

// Dashboard simulation refresh.
$("#refreshDashboard")?.addEventListener("click", () => {
  const random = (min, max, decimals = 0) => (Math.random() * (max - min) + min).toFixed(decimals);
  $("#metricSessions").textContent = Number(random(900, 1800)).toLocaleString();
  $("#metricConversion").textContent = `${random(3.2, 6.8, 2)}%`;
  $("#metricResponse").innerHTML = `${random(130, 260)}<span class="metric-unit">ms</span>`;
  $("#metricUptime").innerHTML = `${random(99.8, 99.99, 2)}<span class="metric-unit">%</span>`;
  const points = Array.from({ length: 7 }, (_, i) => 35 + Math.random() * 145);
  const path = points.map((y, i) => `${i ? "L" : "M"}${i * (700 / 6)},${220 - y}`).join(" ");
  const line = $("#trafficChart .chart-line");
  const area = $("#trafficChart .chart-area-fill");
  if (line) line.setAttribute("d", path);
  if (area) area.setAttribute("d", `${path} L700,220 L0,220 Z`);
});

// Etch-a-Sketch canvas with pointer events (mouse, pen and touch).
const canvas = $("#drawCanvas");
const ctx = canvas?.getContext("2d");
let drawing = false, lastPoint = null;
function resizeCanvas() {
  if (!canvas || !ctx) return;
  const rect = canvas.getBoundingClientRect();
  const old = document.createElement("canvas");
  old.width = canvas.width; old.height = canvas.height;
  if (old.width && old.height) old.getContext("2d").drawImage(canvas, 0, 0);
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(rect.width * ratio);
  canvas.height = Math.round(rect.height * ratio);
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  ctx.lineCap = "round"; ctx.lineJoin = "round";
  ctx.fillStyle = "#10151b"; ctx.fillRect(0, 0, rect.width, rect.height);
  if (old.width && old.height) ctx.drawImage(old, 0, 0, old.width, old.height, 0, 0, rect.width, rect.height);
}
function canvasPoint(event) {
  const rect = canvas.getBoundingClientRect();
  return { x: event.clientX - rect.left, y: event.clientY - rect.top };
}
if (canvas && ctx) {
  resizeCanvas();
  window.addEventListener("resize", resizeCanvas);
  canvas.addEventListener("pointerdown", event => {
    drawing = true; lastPoint = canvasPoint(event); canvas.setPointerCapture(event.pointerId);
    $("#canvasCoords").textContent = `X: ${Math.round(lastPoint.x)} / Y: ${Math.round(lastPoint.y)}`;
  });
  canvas.addEventListener("pointermove", event => {
    const point = canvasPoint(event);
    $("#canvasCoords").textContent = `X: ${Math.round(point.x)} / Y: ${Math.round(point.y)}`;
    if (!drawing || !lastPoint) return;
    ctx.strokeStyle = $("#brushColor").value;
    ctx.lineWidth = Number($("#brushSize").value);
    ctx.beginPath(); ctx.moveTo(lastPoint.x, lastPoint.y); ctx.lineTo(point.x, point.y); ctx.stroke();
    lastPoint = point;
  });
  const stopDrawing = () => { drawing = false; lastPoint = null; };
  canvas.addEventListener("pointerup", stopDrawing);
  canvas.addEventListener("pointercancel", stopDrawing);
  canvas.addEventListener("pointerleave", event => { if (event.buttons === 0) stopDrawing(); });
  $("#clearCanvas").addEventListener("click", () => {
    const rect = canvas.getBoundingClientRect(); ctx.fillStyle = "#10151b"; ctx.fillRect(0, 0, rect.width, rect.height);
  });
}

// To-do list and notes use namespaced localStorage keys.
const TODO_KEY = "wz-todos-v1", NOTES_KEY = "wz-notes-v1";
let todos = [];
try { todos = JSON.parse(localStorage.getItem(TODO_KEY) || "[]"); if (!Array.isArray(todos)) todos = []; } catch { todos = []; }
function saveTodos() { localStorage.setItem(TODO_KEY, JSON.stringify(todos)); renderTodos(); }
function renderTodos() {
  const list = $("#todoList"); if (!list) return;
  list.replaceChildren();
  if (!todos.length) { const li = document.createElement("li"); li.className = "empty-state"; li.textContent = "Nothing here yet. Add your first task above."; list.append(li); }
  todos.forEach(todo => {
    const li = document.createElement("li"); li.classList.toggle("done", todo.done);
    const check = document.createElement("input"); check.type = "checkbox"; check.checked = todo.done; check.setAttribute("aria-label", `Mark ${todo.text} complete`);
    check.addEventListener("change", () => { todo.done = check.checked; saveTodos(); });
    const text = document.createElement("span"); text.className = "todo-text"; text.textContent = todo.text;
    const remove = document.createElement("button"); remove.className = "todo-delete"; remove.type = "button"; remove.textContent = "×"; remove.setAttribute("aria-label", `Delete ${todo.text}`);
    remove.addEventListener("click", () => { todos = todos.filter(item => item.id !== todo.id); saveTodos(); });
    li.append(check, text, remove); list.append(li);
  });
  const remaining = todos.filter(todo => !todo.done).length;
  $("#todoCount").textContent = `${remaining} remaining · ${todos.length} total`;
}
$("#todoForm")?.addEventListener("submit", event => {
  event.preventDefault(); const input = $("#todoInput"), text = input.value.trim();
  if (!text) return;
  todos.unshift({ id: `${Date.now()}-${Math.random()}`, text, done: false }); input.value = ""; saveTodos(); input.focus();
});
$("#clearCompleted")?.addEventListener("click", () => { todos = todos.filter(todo => !todo.done); saveTodos(); });
renderTodos();
const notesInput = $("#notesInput"), notesStatus = $("#notesStatus");
if (notesInput) {
  notesInput.value = localStorage.getItem(NOTES_KEY) || "";
  let notesDebounce;
  notesInput.addEventListener("input", () => {
    notesStatus.textContent = "Saving…";
    clearTimeout(notesDebounce);
    notesDebounce = setTimeout(() => { localStorage.setItem(NOTES_KEY, notesInput.value); notesStatus.textContent = "Saved locally ✓"; }, 250);
  });
}

// API-ready widgets. Keep keys blank for safe public demo deployments.
const WEATHER_API_KEY = ""; // Add an OpenWeatherMap API key for live weather.
const UNSPLASH_ACCESS_KEY = ""; // Add an Unsplash Access Key for image search.
$("#weatherForm")?.addEventListener("submit", async event => {
  event.preventDefault();
  const city = $("#weatherCity").value.trim(), result = $("#weatherResult");
  if (!city) return;
  if (!WEATHER_API_KEY) {
    result.innerHTML = `<span class="weather-symbol">⌁</span><div><strong>${escapeHTML(city)}</strong><small>Add your OpenWeatherMap key to WEATHER_API_KEY in script.js to fetch live conditions.</small></div>`;
    return;
  }
  result.innerHTML = `<span class="weather-symbol">…</span><div><strong>Loading weather</strong><small>Contacting weather service…</small></div>`;
  try {
    const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${encodeURIComponent(WEATHER_API_KEY)}&units=metric`);
    if (!response.ok) throw new Error("Weather request failed. Check the city and API key.");
    const data = await response.json();
    result.innerHTML = `<span class="weather-symbol">☼</span><div><strong>${escapeHTML(data.name)} · ${Math.round(data.main.temp)}°C</strong><small>${escapeHTML(data.weather?.[0]?.description || "Current conditions")} · Feels like ${Math.round(data.main.feels_like)}°C</small></div>`;
  } catch (error) { result.innerHTML = `<span class="weather-symbol">!</span><div><strong>Could not load weather</strong><small>${escapeHTML(error.message)}</small></div>`; }
});
$("#imageSearchForm")?.addEventListener("submit", async event => {
  event.preventDefault();
  const query = $("#imageQuery").value.trim(), results = $("#imageResults");
  if (!query) return;
  if (!UNSPLASH_ACCESS_KEY) {
    results.innerHTML = `<div class="image-placeholder" style="grid-column:1/-1;height:100px"><span>To enable image search, add an Unsplash key to UNSPLASH_ACCESS_KEY in script.js.</span></div>`;
    return;
  }
  results.innerHTML = `<div class="image-placeholder" style="grid-column:1/-1"><span>Searching…</span></div>`;
  try {
    const response = await fetch(`https://api.unsplash.com/search/photos?query=${encodeURIComponent(query)}&per_page=6&client_id=${encodeURIComponent(UNSPLASH_ACCESS_KEY)}`);
    if (!response.ok) throw new Error("Image search request failed.");
    const data = await response.json(); results.replaceChildren();
    if (!data.results?.length) { results.innerHTML = '<div class="empty-state">No images found. Try another search.</div>'; return; }
    data.results.forEach(item => {
      const a = document.createElement("a"); a.className = "image-placeholder"; a.href = item.links.html; a.target = "_blank"; a.rel = "noopener noreferrer"; a.setAttribute("aria-label", item.alt_description || query);
      const img = document.createElement("img"); img.src = item.urls.small; img.alt = item.alt_description || query; img.loading = "lazy"; a.append(img); results.append(a);
    });
  } catch (error) { results.innerHTML = `<div class="empty-state">${escapeHTML(error.message)}</div>`; }
});
function escapeHTML(value) { return String(value).replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char])); }

// Contact validation (demo only; there is no backend endpoint).
$("#contactForm")?.addEventListener("submit", event => {
  event.preventDefault();
  const form = event.currentTarget, fields = ["contactName", "contactEmail", "contactSubject", "contactMessage"].map(id => $("#" + id));
  let valid = true;
  fields.forEach(field => {
    const value = field.value.trim();
    const emailValid = field.id !== "contactEmail" || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
    const fieldValid = value.length > 0 && emailValid;
    field.classList.toggle("is-invalid", !fieldValid); field.classList.toggle("is-valid", fieldValid);
    if (!fieldValid) valid = false;
  });
  const alert = $("#contactAlert");
  alert.classList.remove("d-none", "alert-success", "alert-danger");
  if (!valid) { alert.classList.add("alert-danger"); alert.textContent = "Please correct the highlighted fields before submitting."; fields.find(field => field.classList.contains("is-invalid"))?.focus(); return; }
  alert.classList.add("alert-success");
  alert.textContent = "Validation successful! This demo has no server, so your message was not sent. Connect a backend or form service to receive messages.";
  form.reset(); fields.forEach(field => field.classList.remove("is-valid"));
});
$$(".contact-panel input, .contact-panel textarea").forEach(field => field.addEventListener("input", () => field.classList.remove("is-invalid", "is-valid")));
$("#footerYear").textContent = new Date().getFullYear();

// Tool hub modal: calculator, demo converter, timer, password, QR, speech, and games.
const modalElement = $("#toolModal");
const toolModal = window.bootstrap ? new bootstrap.Modal(modalElement) : null;
const modalBody = $("#toolModalBody");
const toolTitles = { calculator: "Quick Calculator", currency: "Currency Converter", timer: "Countdown Timer", password: "Password Generator", qr: "QR Code Generator", speech: "Text to Speech", guess: "Number Guess", reaction: "Reaction Test", ttt: "Tic-Tac-Toe" };
let timerInterval = null, reactionTimeout = null, reactionStart = 0, reactionState = "idle", guessTarget = 0, guessAttempts = 0, tttBoard = Array(9).fill(""), tttTurn = "X", calcExpression = "";
function setToolContent(html) { modalBody.innerHTML = html; }
function openTool(tool) {
  clearInterval(timerInterval); clearTimeout(reactionTimeout); reactionState = "idle";
  $("#toolModalTitle").textContent = toolTitles[tool] || "Interactive Demo";
  const views = {
    calculator: `<p class="modal-note">Use the buttons or keyboard. Division by zero and invalid expressions are rejected.</p><div class="tool-output" id="calcDisplay" aria-live="polite">0</div><div class="tool-grid">${["7","8","9","÷","4","5","6","×","1","2","3","−","C","0",".","+","⌫","(",")","="].map(k=>`<button class="calc-key ${["÷","×","−","+","="].includes(k)?"operator":""}" data-calc="${k}">${k}</button>`).join("")}</div>`,
    currency: `<label class="form-label" for="currencyAmount">Amount</label><input class="form-control" id="currencyAmount" type="number" min="0" step="any" value="1"><div class="row g-2 mt-2"><div class="col-5"><select class="form-select" id="currencyFrom"><option value="USD">USD</option><option value="ZAR">ZAR</option><option value="GBP">GBP</option><option value="EUR">EUR</option><option value="ZWG">ZWG (ZiG)</option></select></div><div class="col-2 text-center align-self-center">→</div><div class="col-5"><select class="form-select" id="currencyTo"><option value="ZWG">ZWG (ZiG)</option><option value="USD">USD</option><option value="ZAR">ZAR</option><option value="GBP">GBP</option><option value="EUR">EUR</option></select></div></div><button class="btn btn-accent tool-full" id="convertCurrency">Convert</button><div class="tool-output" id="currencyOutput">Rates are illustrative demo values, not financial advice.</div><p class="modal-note">Demo base rates are intentionally editable in script.js; verify live rates before using for transactions.</p>`,
    timer: `<p class="modal-note">Set a duration and start a focus countdown.</p><div class="row g-2"><div class="col-6"><label class="form-label" for="timerMinutes">Minutes</label><input class="form-control" id="timerMinutes" type="number" min="0" max="999" value="5"></div><div class="col-6"><label class="form-label" for="timerSeconds">Seconds</label><input class="form-control" id="timerSeconds" type="number" min="0" max="59" value="0"></div></div><div class="tool-output text-center" id="timerDisplay" style="font:32px 'DM Mono',monospace">05:00</div><div class="d-flex gap-2"><button class="btn btn-accent flex-fill" id="timerStart">Start</button><button class="btn btn-outline-soft flex-fill" id="timerPause">Pause</button><button class="btn btn-outline-soft flex-fill" id="timerReset">Reset</button></div>`,
    password: `<label class="form-label" for="passwordLength">Password length: <span id="passwordLengthLabel">16</span></label><input class="form-range" id="passwordLength" type="range" min="8" max="48" value="16"><div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" id="passSymbols" checked><label class="form-check-label small" for="passSymbols">Symbols</label></div><div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" id="passNumbers" checked><label class="form-check-label small" for="passNumbers">Numbers</label></div><div class="tool-output" id="passwordOutput">Click generate to create a password.</div><div class="d-flex gap-2"><button class="btn btn-accent flex-fill" id="generatePassword">Generate</button><button class="btn btn-outline-soft flex-fill" id="copyPassword">Copy</button></div>`,
    qr: `<label class="form-label" for="qrText">Text or URL</label><input class="form-control" id="qrText" placeholder="https://example.com" value="https://example.com"><button class="btn btn-accent tool-full" id="makeQR">Generate QR code</button><div class="tool-output qr-output text-center" id="qrOutput">QR preview will appear here. Requires an internet connection to load the QR image service.</div><p class="modal-note">The QR preview is generated by a third-party image endpoint. Avoid submitting sensitive information.</p>`,
    speech: `<label class="form-label" for="speechText">Text to read aloud</label><textarea class="form-control" id="speechText" rows="4" placeholder="Type something for your browser to speak...">Hello, welcome to Weston's portfolio.</textarea><label class="form-label mt-3" for="speechVoice">Voice</label><select class="form-select" id="speechVoice"><option value="">Default voice</option></select><div class="d-flex gap-2 mt-3"><button class="btn btn-accent flex-fill" id="speakText">Speak</button><button class="btn btn-outline-soft flex-fill" id="stopSpeech">Stop</button></div><p class="modal-note">Available voices depend on your browser and operating system.</p>`,
    guess: `<p class="modal-note">A secret number from 1 to 100 is waiting. You have seven guesses.</p><form id="guessForm" class="input-row"><input class="form-control" id="guessInput" type="number" min="1" max="100" placeholder="Your guess" required><button class="btn btn-accent">Guess</button></form><div class="tool-output" id="guessOutput">Enter a number to start.</div><button class="btn btn-outline-soft tool-full" id="guessReset">New number</button>`,
    reaction: `<p class="modal-note">Click start, wait for the panel to turn green, then click as quickly as possible. Clicking early resets the test.</p><button id="reactionPad" class="reaction-pad">Start test</button><div class="tool-output text-center" id="reactionOutput">Best reflex wins.</div>`,
    ttt: `<p class="modal-note">Two players, one board. X starts.</p><div class="game-board" id="tttBoard">${Array.from({length:9},(_,i)=>`<button class="ttt-cell" data-ttt="${i}" aria-label="Cell ${i+1}"></button>`).join("")}</div><div class="tool-output text-center" id="tttStatus">Player X's turn</div><button class="btn btn-outline-soft tool-full" id="tttReset">Reset game</button>`
  };
  setToolContent(views[tool] || '<p class="empty-state">Demo unavailable.</p>');
  wireTool(tool);
  toolModal?.show();
}
$$(".demo-btn").forEach(button => button.addEventListener("click", () => openTool(button.dataset.tool)));

function wireTool(tool) {
  if (tool === "calculator") {
    const display = $("#calcDisplay");
    modalBody.addEventListener("click", function calcHandler(event) {
      const key = event.target.closest("[data-calc]"); if (!key) return;
      const value = key.dataset.calc;
      if (value === "C") calcExpression = "";
      else if (value === "⌫") calcExpression = calcExpression.slice(0, -1);
      else if (value === "=") {
        try {
          const normalized = calcExpression.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-");
          if (!/^[\d+\-*/().\s]+$/.test(normalized) || !normalized.trim()) throw new Error();
          const result = Function(`"use strict"; return (${normalized})`)();
          if (!Number.isFinite(result)) throw new Error();
          calcExpression = String(Number(result.toFixed(10)));
        } catch { calcExpression = ""; display.textContent = "Invalid expression"; return; }
      } else calcExpression += ({ "×": "*", "÷": "/", "−": "-" }[value] || value);
      display.textContent = calcExpression || "0";
    });
  }
  if (tool === "currency") {
    const rates = { USD: 1, ZAR: 18.2, GBP: .78, EUR: .92, ZWG: 27.5 }; // illustrative units per USD
    $("#convertCurrency").addEventListener("click", () => {
      const amount = Number($("#currencyAmount").value), from = $("#currencyFrom").value, to = $("#currencyTo").value;
      if (!Number.isFinite(amount) || amount < 0) { $("#currencyOutput").textContent = "Enter a valid non-negative amount."; return; }
      const result = amount / rates[from] * rates[to];
      $("#currencyOutput").textContent = `${amount.toLocaleString()} ${from} ≈ ${result.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${to}`;
    });
  }
  if (tool === "timer") {
    let remaining = 300, running = false;
    const display = $("#timerDisplay");
    const update = () => { display.textContent = `${String(Math.floor(remaining / 60)).padStart(2,"0")}:${String(remaining % 60).padStart(2,"0")}`; };
    const readInputs = () => Math.max(0, Math.min(999*60+59, Number($("#timerMinutes").value || 0)*60 + Number($("#timerSeconds").value || 0)));
    $("#timerStart").addEventListener("click", () => {
      if (!running && remaining <= 0) remaining = readInputs();
      if (remaining <= 0 || running) return;
      running = true; timerInterval = setInterval(() => { remaining--; update(); if (remaining <= 0) { clearInterval(timerInterval); running = false; display.textContent = "Time's up!"; } }, 1000);
    });
    $("#timerPause").addEventListener("click", () => { clearInterval(timerInterval); running = false; });
    $("#timerReset").addEventListener("click", () => { clearInterval(timerInterval); running = false; remaining = readInputs(); update(); });
    ["timerMinutes","timerSeconds"].forEach(id => $("#" + id).addEventListener("input", () => { if (!running) { remaining = readInputs(); update(); } }));
  }
  if (tool === "password") {
    const length = $("#passwordLength"), output = $("#passwordOutput");
    length.addEventListener("input", () => $("#passwordLengthLabel").textContent = length.value);
    $("#generatePassword").addEventListener("click", () => {
      let chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
      if ($("#passNumbers").checked) chars += "0123456789";
      if ($("#passSymbols").checked) chars += "!@#$%^&*()-_=+[]{}?";
      const random = new Uint32Array(Number(length.value)); crypto.getRandomValues(random);
      output.textContent = Array.from(random, n => chars[n % chars.length]).join("");
    });
    $("#copyPassword").addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(output.textContent); $("#copyPassword").textContent = "Copied ✓"; }
      catch { $("#copyPassword").textContent = "Copy unavailable"; }
    });
  }
  if (tool === "qr") $("#makeQR").addEventListener("click", () => {
    const text = $("#qrText").value.trim(), out = $("#qrOutput"); out.replaceChildren();
    if (!text) { out.textContent = "Enter some text or a URL first."; return; }
    const img = document.createElement("img"); img.alt = "Generated QR code"; img.loading = "lazy";
    img.src = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(text)}`;
    img.onerror = () => { out.textContent = "Could not load the QR service. Check your internet connection."; };
    out.append(img);
  });
  if (tool === "speech") {
    const voiceSelect = $("#speechVoice"), synth = window.speechSynthesis;
    function loadVoices() { (synth?.getVoices() || []).forEach((voice, i) => { const option = document.createElement("option"); option.value = String(i); option.textContent = `${voice.name} (${voice.lang})`; voiceSelect.append(option); }); }
    loadVoices(); if (synth) synth.onvoiceschanged = () => { voiceSelect.replaceChildren(new Option("Default voice", "")); loadVoices(); };
    $("#speakText").addEventListener("click", () => {
      if (!synth) { alert("Text-to-speech is not supported by this browser."); return; }
      const text = $("#speechText").value.trim(); if (!text) return;
      synth.cancel(); const utterance = new SpeechSynthesisUtterance(text);
      const voices = synth.getVoices(); if (voiceSelect.value !== "") utterance.voice = voices[Number(voiceSelect.value)];
      synth.speak(utterance);
    });
    $("#stopSpeech").addEventListener("click", () => synth?.cancel());
    modalElement.addEventListener("hidden.bs.modal", () => synth?.cancel(), { once: true });
  }
  if (tool === "guess") {
    const reset = () => { guessTarget = Math.floor(Math.random()*100)+1; guessAttempts = 0; $("#guessOutput").textContent = "A new number is ready. Seven guesses."; $("#guessInput").value = ""; };
    reset();
    $("#guessForm").addEventListener("submit", event => {
      event.preventDefault(); const value = Number($("#guessInput").value);
      if (!Number.isInteger(value) || value < 1 || value > 100) return;
      guessAttempts++;
      if (value === guessTarget) $("#guessOutput").textContent = `Correct! ${value} was the number. You got it in ${guessAttempts} ${guessAttempts===1?"try":"tries"}.`;
      else if (guessAttempts >= 7) $("#guessOutput").textContent = `Out of guesses! The number was ${guessTarget}.`;
      else $("#guessOutput").textContent = `${value < guessTarget ? "Too low" : "Too high"} — ${7-guessAttempts} guesses left.`;
      if (value === guessTarget || guessAttempts >= 7) $("#guessForm button").disabled = true;
    });
    $("#guessReset").addEventListener("click", () => { $("#guessForm button").disabled = false; reset(); });
  }
  if (tool === "reaction") {
    const pad = $("#reactionPad"), output = $("#reactionOutput");
    pad.addEventListener("click", () => {
      if (reactionState === "idle") {
        reactionState = "waiting"; pad.className = "reaction-pad waiting"; pad.textContent = "Wait for green…"; output.textContent = "Don't click yet!";
        reactionTimeout = setTimeout(() => { reactionState = "ready"; reactionStart = performance.now(); pad.className = "reaction-pad ready"; pad.textContent = "CLICK NOW!"; }, 1200 + Math.random()*3000);
      } else if (reactionState === "waiting") {
        clearTimeout(reactionTimeout); reactionState = "idle"; pad.className = "reaction-pad"; pad.textContent = "Too soon — try again"; output.textContent = "You clicked before green appeared.";
      } else {
        const ms = Math.round(performance.now() - reactionStart); reactionState = "idle"; pad.className = "reaction-pad"; pad.textContent = "Start again"; output.textContent = `Reaction time: ${ms} ms`;
      }
    });
  }
  if (tool === "ttt") {
    const render = () => {
      $$("[data-ttt]", modalBody).forEach((cell, i) => { cell.textContent = tttBoard[i]; cell.disabled = Boolean(tttBoard[i]) || Boolean(tttWinner()); });
      const winner = tttWinner();
      $("#tttStatus").textContent = winner ? (winner === "draw" ? "It's a draw!" : `Player ${winner} wins!`) : `Player ${tttTurn}'s turn`;
    };
    const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    function winnerCheck() { for (const [a,b,c] of wins) if (tttBoard[a] && tttBoard[a] === tttBoard[b] && tttBoard[a] === tttBoard[c]) return tttBoard[a]; return tttBoard.every(Boolean) ? "draw" : null; }
    tttWinner = winnerCheck;
    $$("[data-ttt]", modalBody).forEach(cell => cell.addEventListener("click", () => {
      const i = Number(cell.dataset.ttt); if (tttBoard[i] || tttWinner()) return;
      tttBoard[i] = tttTurn; tttTurn = tttTurn === "X" ? "O" : "X"; render();
    }));
    $("#tttReset").addEventListener("click", () => { tttBoard = Array(9).fill(""); tttTurn = "X"; render(); });
    render();
  }
}
let tttWinner = () => null;
modalElement?.addEventListener("hidden.bs.modal", () => { clearInterval(timerInterval); clearTimeout(reactionTimeout); if (window.speechSynthesis) window.speechSynthesis.cancel(); });

// Interactive 3D globe. Fails gracefully if CDN libraries or texture are unavailable.
let globeInstance = null, globeRenderer = null, globeScene = null, globeCamera = null, globeControls = null;
const globeLocations = {
  harare: { name: "Harare, Zimbabwe", code: "ZW / 001", lat: -17.83, lng: 31.05, description: "A starting point close to home — Zimbabwe's capital and a place to connect ideas, people and technology." },
  london: { name: "London, United Kingdom", code: "GB / 002", lat: 51.51, lng: -0.13, description: "A global city with a rich mix of design, engineering, culture and creative industries." },
  tokyo: { name: "Tokyo, Japan", code: "JP / 003", lat: 35.68, lng: 139.69, description: "A fast-moving technology and design hub known for precision, craft and future-facing ideas." },
  newyork: { name: "New York, USA", code: "US / 004", lat: 40.71, lng: -74.01, description: "A global crossroads for startups, media, business and digital product innovation." }
};
function selectGlobeLocation(key) {
  const location = globeLocations[key]; if (!location) return;
  $("#locationCode").textContent = location.code; $("#locationName").textContent = location.name;
  $("#locationDescription").textContent = location.description; $("#locationLat").textContent = `${Math.abs(location.lat).toFixed(2)}° ${location.lat < 0 ? "S" : "N"}`;
  $("#locationLng").textContent = `${Math.abs(location.lng).toFixed(2)}° ${location.lng < 0 ? "W" : "E"}`;
  $$(".location-button").forEach(button => button.classList.toggle("active", button.dataset.location === key));
  if (globeInstance && typeof globeInstance.pointOfView === "function") globeInstance.pointOfView({ lat: location.lat, lng: location.lng, altitude: 1.8 }, 900);
}
$$(".location-button").forEach(button => button.addEventListener("click", () => selectGlobeLocation(button.dataset.location)));
function initGlobe() {
  const container = $("#globeContainer");
  if (!container || !window.THREE || !window.ThreeGlobe) {
    if (container) container.innerHTML = '<div class="empty-state" style="padding:40px;text-align:center">3D globe needs an internet connection to load its rendering libraries. The location selector remains available.</div>';
    return;
  }
  try {
    globeScene = new THREE.Scene();
    globeCamera = new THREE.PerspectiveCamera(45, container.clientWidth / Math.max(container.clientHeight, 1), .1, 1000);
    globeCamera.position.z = 270;
    globeRenderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    globeRenderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    globeRenderer.setSize(container.clientWidth, Math.max(container.clientHeight, 350));
    container.appendChild(globeRenderer.domElement);
    globeInstance = new ThreeGlobe()
      .globeImageUrl("https://unpkg.com/three-globe/example/img/earth-blue-marble.jpg")
      .bumpImageUrl("https://unpkg.com/three-globe/example/img/earth-topology.png")
      .backgroundColor("rgba(0,0,0,0)")
      .showAtmosphere(true).atmosphereColor("#6ea8ff").atmosphereAltitude(.16)
      .pointsData(Object.entries(globeLocations).map(([id, loc]) => ({ ...loc, id })))
      .pointLat("lat").pointLng("lng").pointColor(() => "#b8ff5c").pointAltitude(.025).pointRadius(.55)
      .pointLabel(d => `<b>${escapeHTML(d.name)}</b>`);
    globeScene.add(globeInstance);
    const ambient = new THREE.AmbientLight(0xffffff, 2.1); globeScene.add(ambient);
    const directional = new THREE.DirectionalLight(0xffffff, 1.8); directional.position.set(1, 1, 1); globeScene.add(directional);
    // Lightweight pointer controls keep the globe draggable without extra dependencies.
    let dragging = false, lastX = 0, lastY = 0, rotationX = 0, rotationY = 0, zoom = 270;
    const rendererCanvas = globeRenderer.domElement;
    rendererCanvas.style.cursor = "grab";
    rendererCanvas.addEventListener("pointerdown", event => { dragging = true; lastX = event.clientX; lastY = event.clientY; rendererCanvas.setPointerCapture(event.pointerId); rendererCanvas.style.cursor = "grabbing"; });
    rendererCanvas.addEventListener("pointermove", event => {
      if (!dragging) return;
      rotationY += (event.clientX - lastX) * .005; rotationX += (event.clientY - lastY) * .005;
      rotationX = Math.max(-1.2, Math.min(1.2, rotationX)); lastX = event.clientX; lastY = event.clientY;
      globeInstance.rotation.y = rotationY; globeInstance.rotation.x = rotationX;
      $("#globeCoords").textContent = `ROT ${Math.round(rotationY*57.3)}° / TILT ${Math.round(rotationX*57.3)}°`;
    });
    const endDrag = () => { dragging = false; rendererCanvas.style.cursor = "grab"; };
    rendererCanvas.addEventListener("pointerup", endDrag); rendererCanvas.addEventListener("pointercancel", endDrag);
    rendererCanvas.addEventListener("wheel", event => { event.preventDefault(); zoom = Math.max(180, Math.min(390, zoom + event.deltaY * .12)); globeCamera.position.z = zoom; }, { passive: false });
    $("#globeZoomIn").addEventListener("click", () => { zoom = Math.max(180, zoom - 25); globeCamera.position.z = zoom; });
    $("#globeZoomOut").addEventListener("click", () => { zoom = Math.min(390, zoom + 25); globeCamera.position.z = zoom; });
    $("#globeReset").addEventListener("click", () => { rotationX = 0; rotationY = 0; zoom = 270; globeInstance.rotation.set(0,0,0); globeCamera.position.z = zoom; selectGlobeLocation("harare"); });
    const resize = () => { const width = container.clientWidth, height = Math.max(container.clientHeight, 350); globeCamera.aspect = width / height; globeCamera.updateProjectionMatrix(); globeRenderer.setSize(width, height); };
    window.addEventListener("resize", resize);
    const animate = () => { requestAnimationFrame(animate); if (!dragging && !reducedMotion) globeInstance.rotation.y += .0007; globeRenderer.render(globeScene, globeCamera); };
    animate();
    selectGlobeLocation("harare");
  } catch (error) {
    container.innerHTML = '<div class="empty-state" style="padding:40px;text-align:center">The 3D globe could not initialize in this browser. Try a current browser with WebGL enabled.</div>';
    console.warn("Globe initialization failed:", error);
  }
}
if ("requestIdleCallback" in window) requestIdleCallback(initGlobe); else setTimeout(initGlobe, 500);
