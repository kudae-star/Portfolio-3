# Weston Kudakwashe Zhanje — Portfolio

## Files
- `index.html` — semantic page structure and CDN dependencies
- `style.css` — responsive theme, layout, and visual design
- `script.js` — all interactions, widgets, mini-games, local storage, canvas, and 3D globe
- `assets/` — the three supplied portrait photos

## Run
Open `index.html` in a modern browser with an internet connection. Bootstrap and the 3D globe libraries load from CDNs. A local web server is recommended for consistent browser behavior (for example, VS Code Live Server).

## API integrations
The weather and Unsplash widgets are wired up but disabled until you add your own keys in `script.js`:
- `WEATHER_API_KEY`
- `UNSPLASH_ACCESS_KEY`

Do not publish private API credentials in a public repository. For production, proxy secret-bearing requests through a backend.
The currency converter uses clearly labelled illustrative demo rates. The contact form validates client-side but does not send email without a backend or form service.

## Features
- Responsive Bootstrap 5 layout, light/dark theme and animated type effect
- Animated skills and simulated analytics dashboard
- Calculator, demo currency converter, timer, password generator, QR generator, text-to-speech
- Number guessing, reaction-time test, Tic-Tac-Toe
- Pointer/touch drawing canvas
- Weather and Unsplash API-ready widgets
- Local-storage to-do list and notes
- Interactive 3D globe with location selectors and zoom controls
